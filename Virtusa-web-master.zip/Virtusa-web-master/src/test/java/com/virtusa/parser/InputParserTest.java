package com.virtusa.parser;

import org.junit.Before;
import org.junit.Test;

/**
 * @author venkateswarlusayana
 *
 */
public class InputParserTest {
    private InputParser parser;

    @Before
    public void setUp() {
        parser = new InputParser();
    }

    @Test
    public void shouldCallFactoryRepository() {
        // Not yet implemented
    }

    @Test
    public void shouldCallFactoryWriter() {
        // Not yet implemented
    }
}

