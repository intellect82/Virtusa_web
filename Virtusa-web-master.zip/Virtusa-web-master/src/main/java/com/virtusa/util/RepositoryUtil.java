package com.virtusa.util;

import com.virtusa.repository.Repository;

/**
 * @author venkateswarlusayana
 *
 */
public class RepositoryUtil {
    public static String lookupSymbolsFromVariables(Repository repository, String[] keys) {
        StringBuffer symbols = new StringBuffer();

        for (String key : keys) {
            symbols.append(repository.get(key));
        }

        return symbols.toString();
    }
}
