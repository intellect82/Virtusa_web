package com.virtusa.repository;

/**
 * @author venkateswarlusayana
 *
 */
public interface Repository {
    void put(String input);

    String get(String key);
}
