package com.virtusa.parser;

import com.virtusa.factory.RepositoryFactory;
import com.virtusa.factory.WriterFactory;

/**
 * @author venkateswarlusayana
 *
 */
public class InputParser {
    private static final String WRITER_LINE_PREFIX = "how ";

    public void parse(String input) {
        for (String line : input.split("\\r?\\n")) {
            parseSingleLine(line);
        }
    }

    public void parseSingleLine(String input) {
        if (input.startsWith(WRITER_LINE_PREFIX)) {
            WriterFactory.getWriter(input).process(input);
        }
        else {
            RepositoryFactory.getRepository(input).put(input);;
        }
    }
}
