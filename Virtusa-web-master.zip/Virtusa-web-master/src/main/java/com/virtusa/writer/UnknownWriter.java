package com.virtusa.writer;

import com.virtusa.repository.CreditRepository;
import com.virtusa.repository.SymbolRepository;

/**
 * @author venkateswarlusayana
 *
 */
public class UnknownWriter implements Writer {
    private static final String UNKNOWN_MESSAGE = "I have no idea what you are talking about";

    public void process(String input) {
        System.out.println(UNKNOWN_MESSAGE);
    }

    public void setSymbolRepository(SymbolRepository symbolRepository) {
    }

    public void setCreditRepository(CreditRepository creditRepository) {
    }
}
