package com.virtusa.writer;

import com.virtusa.repository.CreditRepository;
import com.virtusa.repository.SymbolRepository;

/**
 * @author venkateswarlusayana
 *
 */
public interface Writer {
    void process(String input);

    void setSymbolRepository(SymbolRepository symbolRepository);

    void setCreditRepository(CreditRepository creditRepository);
}